# num=int(input("Enter any number"))
# if(num%2==0):
#     print(num)
# else:
#     print("it is not prime number.")

print(__name__)
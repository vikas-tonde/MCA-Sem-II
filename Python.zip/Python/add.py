a= input("Enter the text: ")
b= int(input("Enter the number 2: "))
s=(input("Enter the string:"))

print(a+b+s)
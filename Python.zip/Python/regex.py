import re
from tarfile import LNKTYPE


m = input("Enter the main string: ")
st = input("Enter the searching string: ")
# x= re.findall(st,m)
# y=re.search(st, m)
# print(f'{st} found in "{m}" {len(x)} times')
# print(f'{st} first occurred in "{m}" at {y.start()+1} position')
# print(f'{st} first occurred in "{m}" at {y.lastindex+1} position')

# c=0
# for i in m.split():
#     if st in i:
#         c+=1

# print(f'{st} found in "{m}" {c} times')

# c = 0
# ln = len(st)
# for i in range(len(m)):
#     if st == m[i:i+ln]:
#         c += 1
# print(f'{st} found in "{m}" {c} times')

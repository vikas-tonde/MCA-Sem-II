import re
a="hello world"
b=re.split("\s",a)


print(b)

l=[i for i in range(1,10)]

print(list(filter(lambda n: n%2==0, l)))
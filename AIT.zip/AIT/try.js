const prompt = require("prompt-sync")({ sigint: true });
// // var n= prompt("ENter the number: ")
// // console.log(n);

// var name= prompt("Enter the name: ");

// console.log(`Hey there ${name}`);

var n = parseInt(prompt("Enter the number: "));
var f = 1;
for (var i = 1; i <= n; i++) {
    f *= i;
}
console.log(`Factorial is ${f}`);